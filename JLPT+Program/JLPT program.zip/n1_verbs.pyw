import tkinter as tk
import random

VERB_FILE = r"C:\Users\dmitr\Desktop\JLPT+Program\n1_verbs.txt"
WORD_FILE = r"C:\Users\dmitr\Desktop\JLPT+Program\n1_words.txt"


def load_cards(path):
    cards = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            parts = [p.strip() for p in line.strip().split("|")]
            if len(parts) == 5:
                cards.append({
                    "front": parts[0],
                    "meaning": parts[1],
                    "readings": parts[2],
                    "jp_ex": parts[3],
                    "en_ex": parts[4],
                })
    return cards


class FlipApp:
    def __init__(self, master, cards):
        self.master = master
        self.cards = cards
        self.queue = cards.copy()
        random.shuffle(self.queue)
        self.current = None
        self.showing_back = False

        self.total = len(cards)
        self.count = 0

        self.counter_label = tk.Label(master, text=f"0 / {self.total}", font=("Arial", 16))
        self.counter_label.pack(pady=5)

        self.front_label = tk.Label(master, text="", font=("Arial", 40), wraplength=800, justify="center")
        self.front_label.pack(pady=30)

        self.back_text = tk.Text(master, font=("Arial", 24), wrap="word", height=14, width=60)
        self.back_text.tag_config("kunyomi", foreground="red")
        self.back_text.tag_config("hdr", foreground="#333", font=("Arial", 24, "bold"))
        self.back_text.tag_config("en", foreground="#2a6", font=("Arial", 22))
        self.back_text.pack_forget()

        self.flip_btn = tk.Button(master, text="Flip", font=("Arial", 16), command=self.flip)
        self.flip_btn.pack(pady=10)

        self.good_btn = tk.Button(master, text="Good", font=("Arial", 16), command=self.good)
        self.no_btn = tk.Button(master, text="No?", font=("Arial", 16), command=self.no)
        self.good_btn.pack_forget()
        self.no_btn.pack_forget()

        master.bind("<space>", lambda e: self.good())
        master.bind("<Escape>", lambda e: self.no())
        master.bind("<Return>", lambda e: self.flip())

        self.next_card()

    def update_counter(self):
        self.counter_label.config(text=f"{self.count} / {self.total}")

    def show_front(self):
        self.back_text.pack_forget()
        self.front_label.pack(pady=30)
        self.good_btn.pack_forget()
        self.no_btn.pack_forget()

    def show_back(self):
        self.front_label.pack_forget()
        self.back_text.pack(pady=20)
        self.good_btn.pack(side="left", padx=30, pady=20)
        self.no_btn.pack(side="right", padx=30, pady=20)

    def render_back(self):
        self.back_text.config(state="normal")
        self.back_text.delete("1.0", "end")

        readings = self.current['readings']
        onyomi = readings
        kunyomi = ""
        if "/" in readings:
            parts = readings.split("/", 1)
            onyomi = parts[0].strip()
            kunyomi = parts[1].strip()

        self.back_text.insert("end", "Meaning:\n", ("hdr",))
        self.back_text.insert("end", f"{self.current['meaning']}\n\n")

        self.back_text.insert("end", "Readings:\n", ("hdr",))
        self.back_text.insert("end", f"Onyomi: {onyomi}\n")
        self.back_text.insert("end", "Kunyomi: ")
        start = self.back_text.index("end")
        self.back_text.insert("end", f"{kunyomi}\n")
        self.back_text.tag_add("kunyomi", start, "end-1c")
        self.back_text.insert("end", "\n")

        self.back_text.insert("end", "Example JP:\n", ("hdr",))
        self.back_text.insert("end", f"{self.current['jp_ex']}\n\n")
        self.back_text.insert("end", "Example EN:\n", ("hdr",))
        self.back_text.insert("end", f"{self.current['en_ex']}\n", ("en",))

        self.back_text.config(state="disabled")

    def next_card(self):
        if not self.queue:
            self.front_label.config(text="All done!")
            self.show_front()
            return
        self.current = self.queue.pop(0)
        self.showing_back = False
        self.front_label.config(text=self.current["front"])
        self.show_front()

    def flip(self):
        if not self.current:
            return
        if self.showing_back:
            self.showing_back = False
            self.show_front()
        else:
            self.showing_back = True
            self.render_back()
            self.show_back()

    def good(self):
        self.count += 1
        self.update_counter()
        self.next_card()

    def no(self):
        delay = random.randint(1, 10)
        pos = min(len(self.queue), delay)
        self.queue.insert(pos, self.current)
        self.count += 1
        self.update_counter()
        self.next_card()


# -------------------------
# MENU WINDOW
# -------------------------

def start_flashcards(path):
    cards = load_cards(path)
    menu.destroy()  # close menu window

    root = tk.Tk()
    root.title("JLPT Flipcards")
    FlipApp(root, cards)
    root.mainloop()


if __name__ == "__main__":
    menu = tk.Tk()
    menu.title("Choose Study Mode")

    tk.Label(menu, text="Select what you want to study:", font=("Arial", 20)).pack(pady=20)

    tk.Button(menu, text="Verbs", font=("Arial", 18),
              width=20, command=lambda: start_flashcards(VERB_FILE)).pack(pady=10)

    tk.Button(menu, text="Words", font=("Arial", 18),
              width=20, command=lambda: start_flashcards(WORD_FILE)).pack(pady=10)

    menu.mainloop()